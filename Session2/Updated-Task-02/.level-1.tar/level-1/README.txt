Decompress "level-2".
Hint: Most compression tools require it's suffix.
